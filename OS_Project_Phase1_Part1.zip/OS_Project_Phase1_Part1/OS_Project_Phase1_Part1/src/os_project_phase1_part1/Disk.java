package os_project_phase1_part1;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Disk {
    ArrayList<Job> Jobs = new ArrayList<Job>();
}
