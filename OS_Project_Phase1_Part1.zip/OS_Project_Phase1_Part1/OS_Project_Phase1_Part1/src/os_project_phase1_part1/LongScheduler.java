package os_project_phase1_part1;

import java.util.ArrayList;

public class LongScheduler {
    // First-In-First-Out for Phase 1
    static ArrayList<Job> SortedJobs = new ArrayList<>();
    
    LongScheduler() {}
    
    public static void loadFromDisk() {
        //SortedJobs = Disk.loadFromDisk();
        //System.out.println(SortedJobs.get(0));
    }
}
