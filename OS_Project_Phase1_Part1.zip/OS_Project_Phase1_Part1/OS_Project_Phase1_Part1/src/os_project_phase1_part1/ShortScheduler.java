package os_project_phase1_part1;

import java.util.ArrayList;

public class ShortScheduler {
    ArrayList<Job> SortedJobs = new ArrayList<>();
    
    public void loadFromLongScheduler() {
        
    }
}
