package os_project_phase1_part1;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/*
 The loader module opens the program file. Programs are loaded into disk. Ancillary programs
 would be needed to process (strip off) the special control "cards" = which start with
 '//'. For example, the '// Job 1 17 2' control card of Job1 is processed by discarding the
 '//', noting that the '1' is the ID of the first job, noting that '17' (or 23 in decimal)
 is the number of words that constitue the instructions of Job 1, and '2' is the priority-
 number (to be used for scheduling of Job 1. All the nubmers are in hex.
 Similar logic for porcessing the data-section, following the instructions and proceded by
 '// Data ...' control cards, also applies. In the case of Job 1, for example, '// Data 14 
 C C', means Job 1's input buffer is 20 (14 in hex), its output buffer size is 12 (C in hex)
 words, and the size of its temporary buffer is 12 (C in hex) words.
 */

public class Loader {
    ArrayList<Job> Jobs = new ArrayList<Job>();
    
    public Loader() {
        
    }
    
    public void load() {
        getJob();
    }
    
    public void getJob() {
        Job job = new Job();
        try {
            File f = new File("src\\os_project_phase1_part1\\ProgramFile-TextVersion.txt");
            Scanner sc = new Scanner(f);
            PCB pcb = new PCB();
            String nextLine = "";
            int temp = 1;
            
            
            while (sc.hasNext()) {
                nextLine = sc.nextLine();
                //pcb.extract(nextLine);
                
                if (nextLine.contains("JOB")) {
                    String jobID = ""; // The ID of the job
                    String numWordsHex = ""; // The number of words in hexadecimal form
                    String priorityStr = ""; // The priority of the job
                    int index = 0;
                    System.out.println("********\t" + nextLine + "\t********");
                    String strippedJob = nextLine.substring(7); // From // JOB 1 17 2 to 1 17 2
                    
                    while (index < strippedJob.length()) {
                        jobID = getJobInfo(strippedJob, index); // Get the job id
                        index += jobID.length(); // Skip the length of the info to the next part
                        index = skipWhitespace(strippedJob, index); // Skip over whitespace
                        
                        numWordsHex = getJobInfo(strippedJob, index);
                        index += numWordsHex.length();
                        index = skipWhitespace(strippedJob, index);
                        
                        priorityStr = getJobInfo(strippedJob, index);
                        index += priorityStr.length();
                        index = skipWhitespace(strippedJob, index);
                    } // By the end of this loop, the info has already been assigned.
                    job =  new Job(jobID, numWordsHex, priorityStr);
                    System.out.println("Job ID: " + job.jobID + "\n"
                                    + "Number of Words: " + job.numWordsInt + "\n"
                                    + "Priority: " + job.priorityInt);
                    // Job info has been confirmed to save successfully
                    // Get the instructions
                    
                // Now, move on to the data part
                }
                if (nextLine.contains("Data")) {
                    String inputBuffer = "";
                    String outputBuffer = "";
                    String tempBuffer = "";
                    int index = 0;
                    System.out.println("****\t" + nextLine + "\t****");
                    String strippedData = nextLine.substring(8);
                    System.out.println("strippedData: " + strippedData);
                    
                    while (index < strippedData.length()) {
                        inputBuffer = getJobInfo(strippedData, index);
                        index += inputBuffer.length();
                        index = skipWhitespace(strippedData, index);
                        
                        outputBuffer = getJobInfo(strippedData, index);
                        index += outputBuffer.length();
                        index = skipWhitespace(strippedData, index);
                        
                        tempBuffer = getJobInfo(strippedData, index);
                        index += tempBuffer.length();
                        index = skipWhitespace(strippedData, index);
                    }
                    job.setDataInfo(inputBuffer, outputBuffer, tempBuffer);
                    System.out.println("Input Buffer: " + job.inputBuffer + "\n"
                                    + "Output Buffer: " + job.outputBuffer + "\n"
                                    + "Temp Buffer: " + job.tempBuffer);
                    
                }
                if (nextLine.contains("END")) {
                    System.out.println("********\tEND OF JOB\t********\n");
                }
                
            }
        } catch (FileNotFoundException ex) {
            System.out.println("error");
        }
    }
    
    public String getJobInfo(String strippedJob, int index) {
        int location = index + 1;
        while (location < strippedJob.length() && !Character.isWhitespace(strippedJob.charAt(location)))
            location++;
        return strippedJob.substring(index, location);
    }
    
    private int skipWhitespace(String line, int index) {
        int current = index;
        while (current < line.length() && Character.isWhitespace(line.charAt(current)))
            current++;
        return current;
    }
    
}
