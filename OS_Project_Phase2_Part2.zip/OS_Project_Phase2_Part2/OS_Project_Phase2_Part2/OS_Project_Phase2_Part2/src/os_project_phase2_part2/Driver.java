/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 *
 * This is the core component of the whole system.
 * 
 */
package os_project_phase2_part2;

/*
 * Driver calls:
 * Loader
 * Long Scheduler
 * Short Scheduler
 */
public class Driver {
    
    public Driver() {
        Loader loader = new Loader();
        Disk disk = new Disk();
        Memory memory = new Memory();
        ShortScheduler shortScheduler = new ShortScheduler();
        PCB pcb = new PCB();
        Dispatcher dispatcher = new Dispatcher();
        CPU cpu = new CPU();
        
        String fileName = "src\\os_project_phase2_part2\\ProgramFile-TextVersion.txt";
        
        loader.load(disk, fileName);
        
        do {
            LongScheduler longScheduler = new LongScheduler();
            longScheduler.loadFromDisk(disk);
            longScheduler.loadToMemory(memory);

            shortScheduler.loadFromMemory(memory);
            shortScheduler.loadToPCB(pcb);

            dispatcher.extract(pcb);
            dispatcher.assign(cpu);

            cpu.decode();
            cpu.execute();
            
            
        } while (!disk.UnsortedJobs.isEmpty());
        
        /*
        LongScheduler longScheduler = new LongScheduler();
        longScheduler.loadFromDisk(disk);
        longScheduler.loadToMemory(memory);
        
        shortScheduler.loadFromMemory(memory);
        shortScheduler.loadToPCB(pcb);
        
        dispatcher.extract(pcb);
        dispatcher.assign(cpu);
        
        cpu.decode();
        cpu.execute();
        */
        
        /* After the loader is done, loop these components
        while (true) {
            LongScheduler(); // Takes the jobs from disk and sorts them
            
            Dispatcher();
            CPU();
            waitforinterrupt();
        }
        */
    }
        
}
