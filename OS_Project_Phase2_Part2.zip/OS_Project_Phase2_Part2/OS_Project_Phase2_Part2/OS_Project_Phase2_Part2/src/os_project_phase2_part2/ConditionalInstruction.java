/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 01
public class ConditionalInstruction extends Instruction {
    String twoBits, OPCODE, BReg, DReg, address;
    String instrType;
    
    public ConditionalInstruction() {}
    
    public ConditionalInstruction(String twoBits, String OPCODE,
                                String BReg, String DReg,
                                String address) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.BReg = BReg;
        this.DReg = DReg;
        this.address = address;
        
        instrType = setInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        System.out.println("********  CONDITIONAL  ********\n"
                        + "2 bits: " + twoBits + "\n"
                        + "OPCODE: " + OPCODE + "\n"
                        + "Instruction Type: " + setInstructionType(OPCODE) + "\n"
                        + "BReg: " + BReg + "\n"
                        + "DReg: " + DReg + "\n"
                        + "Address: " + address + "\n");
    }
    
    public String getInstructionType() {
        return instrType;
    }
}
