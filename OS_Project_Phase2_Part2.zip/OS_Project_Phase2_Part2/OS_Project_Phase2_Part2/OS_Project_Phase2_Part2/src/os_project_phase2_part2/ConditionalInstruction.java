/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 01
public class ConditionalInstruction extends Instruction {
    String twoBits, OPCODE, BReg, DReg, address;
    String instrType;
    
    public ConditionalInstruction() {}
    
    public ConditionalInstruction(String twoBits, String OPCODE,
                                String BReg, String DReg,
                                String address) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.BReg = BReg;
        this.DReg = DReg;
        this.address = address;
        
        instrType = setInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        System.out.println("\t********  CONDITIONAL  ********\n"
                        + "\t2 bits: " + twoBits + "\n"
                        + "\tOPCODE: " + OPCODE + "\n"
                        + "\tInstruction Type: " + setInstructionType(OPCODE) + "\n"
                        + "\tBReg: " + BReg + "\n"
                        + "\tDReg: " + DReg + "\n"
                        + "\tAddress: " + address + "\n");
    }
    
    public String getInstructionType() {
        return instrType;
    }
}
