/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.math.BigInteger;
import java.util.ArrayList;

public class CPU {
    Job job = new Job();
    ArrayList<Instruction> instructions = new ArrayList<>();
    ArrayList<Instruction> dataInstructions = new ArrayList<>();
    int pc = 0; // The program counter
    
    CPU () {}
    
    public void fetch(Job job) {
        this.job = job;
    }
    
    public void decode() {
        for (int i = 0; i < job.instructions.size(); i++) {
            // Get the string of the instruction
            String instrID = job.instructions.get(i);
            // Convert the instruction to hexadecimal
            String instrHex = getInstructionHex(instrID);
            // Convert the hexadecimal instruction to binary
            String instrBin = hexToBin(instrHex);
            getInstruction(instrBin);
        }        
    }
    
    public void execute() {
        for (int i = 0; i < job.instructions.size(); i++) {
            if (!instructions.get(i).getInstructionType().equalsIgnoreCase("unsuccessul")) {
                pc++;
            }
        }
        System.out.println("Successful executions:\t" + pc);
    }
    
    public void getInstruction(String instrBin) {
        // Get first two bits of instruction to get format
        String twoBits = instrBin.substring(0, 2);
        switch (twoBits) {
            // Arithmetic Instruction Format
            case "00":
                getArithmeticInstruction(instrBin);
                break;
            // Conditional Branch and Immediate Format
            case "01":
                getConditionalInstruction(instrBin);
                break;
            // Unconditional Jump Format
            case "10":
                getUnconditionalInstruction(instrBin);
                break;
            // Input and Output Instruction Format
            case "11":
                getIOInstruction(instrBin);
                break;
        }
    }
    private void getArithmeticInstruction(String instrBin) {
        //     2        6       4      4      4     12 
        String twoBits, OPCODE, SReg1, SReg2, DReg, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        SReg1 = instrBin.substring(8, 12);
        SReg2 = instrBin.substring(12, 16);
        DReg = instrBin.substring(16, 20);
        address = instrBin.substring(20);
        
        ArithmeticInstruction instrA = new ArithmeticInstruction(twoBits, OPCODE,
                                                                SReg1, SReg2,
                                                                DReg, address);
        instructions.add(instrA);
    }
    private void getConditionalInstruction(String instrBin) {
        //     2        6       4     4     16
        String twoBits, OPCODE, BReg, DReg, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        BReg = instrBin.substring(8, 12);
        DReg = instrBin.substring(12, 16);
        address = instrBin.substring(16);
        
        ConditionalInstruction instrC = new ConditionalInstruction(twoBits, OPCODE, BReg,
                                                                    DReg, address);
        instructions.add(instrC);
    }
    private void getUnconditionalInstruction(String instrBin) {
        String twoBits, OPCODE, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        address = instrBin.substring(8);
        
        UnconditionalInstruction instrU = new UnconditionalInstruction(twoBits, OPCODE, address);
        instructions.add(instrU);
    }
    private void getIOInstruction(String instrBin) {
        String twoBits, OPCODE, reg1, reg2, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        reg1 = instrBin.substring(8, 12);
        reg2 = instrBin.substring(12, 16);
        address = instrBin.substring(16);
        
        IOInstruction instrIO = new IOInstruction(twoBits, OPCODE, reg1,
                                                                reg2, address);
        instructions.add(instrIO);
    }
    
    public void getDataInstruction(String dataInstrBin) {
        // Get first two bits of instruction to get format
        String twoBits = dataInstrBin.substring(0, 2);
        switch (twoBits) {
            // Arithmetic Instruction Format
            case "00":
                getArithmeticDataInstruction(dataInstrBin);
                break;
            // Conditional Branch and Immediate Format
            case "01":
                getConditionalDataInstruction(dataInstrBin);
                break;
            // Unconditional Jump Format
            case "10":
                getUnconditionalDataInstruction(dataInstrBin);
                break;
            // Input and Output Instruction Format
            case "11":
                getIODataInstruction(dataInstrBin);
                break;
        }
    }
    private void getArithmeticDataInstruction(String dataInstrBin) {
        //     2        6       4      4      4     12 
        String twoBits, OPCODE, SReg1, SReg2, DReg, address;
        
        twoBits = dataInstrBin.substring(0, 2);
        OPCODE = dataInstrBin.substring(2, 8);
        SReg1 = dataInstrBin.substring(8, 12);
        SReg2 = dataInstrBin.substring(12, 16);
        DReg = dataInstrBin.substring(16, 20);
        address = dataInstrBin.substring(20);
        
        ArithmeticInstruction dataInstrA = new ArithmeticInstruction(twoBits, OPCODE,
                                                                SReg1, SReg2,
                                                                DReg, address);
        instructions.add(dataInstrA);
    }
    private void getConditionalDataInstruction(String dataInstrBin) {
        //     2        6       4     4     16
        String twoBits, OPCODE, BReg, DReg, address;
        
        twoBits = dataInstrBin.substring(0, 2);
        OPCODE = dataInstrBin.substring(2, 8);
        BReg = dataInstrBin.substring(8, 12);
        DReg = dataInstrBin.substring(12, 16);
        address = dataInstrBin.substring(16);
        
        ConditionalInstruction dataInstrC = new ConditionalInstruction(twoBits, OPCODE, BReg,
                                                                    DReg, address);
        instructions.add(dataInstrC);
    }
    private void getUnconditionalDataInstruction(String dataInstrBin) {
        String twoBits, OPCODE, address;
        
        twoBits = dataInstrBin.substring(0, 2);
        OPCODE = dataInstrBin.substring(2, 8);
        address = dataInstrBin.substring(8);
        
        UnconditionalInstruction dataInstrU = new UnconditionalInstruction(twoBits, OPCODE, address);
        instructions.add(dataInstrU);
    }
    private void getIODataInstruction(String dataInstrBin) {
        String twoBits, OPCODE, reg1, reg2, address;
        
        twoBits = dataInstrBin.substring(0, 2);
        OPCODE = dataInstrBin.substring(2, 8);
        reg1 = dataInstrBin.substring(8, 12);
        reg2 = dataInstrBin.substring(12, 16);
        address = dataInstrBin.substring(16);
        
        IOInstruction dataInstrIO = new IOInstruction(twoBits, OPCODE, reg1,
                                                                reg2, address);
        instructions.add(dataInstrIO);
    }
    
    public void printInstructions() {
        System.out.println("********  INSTRUCTIONS  ********");
        for (int i = 0; i < instructions.size(); i++) {
            System.out.println("INSTRUCTION " + (i + 1));
            instructions.get(i).printInstruction();
        }
        System.out.println("********  DATA INSTRUCTIONS  ********");
        for (int i = 0; i < dataInstructions.size(); i++) {
            System.out.println("DATA INSTRUCTION " + (i + 1));
            dataInstructions.get(i).printInstruction();
        }
    }
    
    public static String getInstructionHex(String instruction) {
        return instruction.substring(2);
    }
    public static String binToHex(String binStr) {
        int bin = Integer.parseInt(binStr, 2);
        return Integer.toString(bin, 16);
    }
    public static String hexToBin(String hex) {
        return new BigInteger(hex, 16).toString(2);
    }
    public static String binToDec(String bin) {
        int dec = Integer.parseInt(bin, 2);
        return Integer.toString(dec);
    }
    
    
    public void printJobs() {
        System.out.println("********  FROM CPU  ********");
        System.out.println("JOB 1");
        job.printJob();
        System.out.println("********  FROM CPU  ********");
    }
}
