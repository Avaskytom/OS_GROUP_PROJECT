/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 11
public class IOInstruction extends Instruction {
    String twoBits, OPCODE, reg1, reg2, address;
    String instrType;
    
    public IOInstruction () {}
    
    public IOInstruction (String twoBits, String OPCODE,
                        String reg1, String reg2,
                        String address) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.reg1 = reg1;
        this.reg2 = reg2;
        this.address = address;
        
        instrType = setInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        System.out.println("\t********  INPUT OUTPUT  ********\n"
                        + "\t2 bits: " + twoBits + "\n"
                        + "\tOPCODE: " + OPCODE + "\n"
                        + "\tInstruction Type: " + setInstructionType(OPCODE) + "\n"
                        + "\tReg1: " + reg1 + "\n"
                        + "\tReg2: " + reg2 + "\n"
                        + "\tAddress: " + address + "\n");
    }
    
    public String getInstructionType() {
        return instrType;
    }
}
