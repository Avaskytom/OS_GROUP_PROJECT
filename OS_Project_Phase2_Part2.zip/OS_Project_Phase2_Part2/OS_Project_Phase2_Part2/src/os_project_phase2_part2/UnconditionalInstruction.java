/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 10
public class UnconditionalInstruction extends Instruction {
    String twoBits, OPCODE, address;
    
    public UnconditionalInstruction () {}
    
    public UnconditionalInstruction (String twoBits, String OPCODE,
                                    String address) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.address = address;
        
        getInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        System.out.println("********  UNCONDITIONAL  ********"
                        + "2 bits: " + twoBits + "\n"
                        + "OPCODE: " + OPCODE + "\n"
                        + "Address: " + address + "\n");
    }
}
