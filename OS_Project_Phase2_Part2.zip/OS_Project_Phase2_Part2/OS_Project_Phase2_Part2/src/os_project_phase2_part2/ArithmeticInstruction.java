/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 00
public class ArithmeticInstruction extends Instruction {
    String twoBits, OPCODE, SReg1, SReg2, DReg, address;
    String instructionType;
    
    public ArithmeticInstruction () {}
    
    public ArithmeticInstruction (String twoBits, String OPCODE,
                                String SReg1, String SReg2,
                                String DReg, String address) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.SReg1 = SReg1;
        this.SReg2 = SReg2;
        this.DReg = DReg;
        this.address = address;
        
        getInstructionType(OPCODE);
    }
    
    public void setTwoBits(String twoBits) {
        this.twoBits = twoBits;
    }
    public String getTwoBits() {
        return twoBits;
    }
    
    public void setOPCODE(String OPCODE) {
        this.OPCODE = OPCODE;
    }
    public String getOPCODE() {
        return OPCODE;
    }
    
    public void setSReg1(String SReg1) {
        this.SReg1 = SReg1;
    }
    public String getSReg1() {
        return SReg1;
    }
    
    public String getSReg2() {
        return SReg2;
    }
    
    public String getDReg() {
        return DReg;
    }
    
    public String getAddress() {
        return address;
    }
}
