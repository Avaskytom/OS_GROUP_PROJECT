/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.math.BigInteger;
import java.util.ArrayList;

public class CPU {
    Job job = new Job();
    ArrayList<Instruction> instructions = new ArrayList<>();
    
    CPU () {}
    
    public void fetch(Job job) {
        this.job = job;
    }
    
    public void decode() {
        
        for (int i = 0; i < job.instructions.size(); i++) {
            // Get the string of the instruction
            String instrID = job.instructions.get(i);
            // Convert the instruction to hexadecimal
            String instrHex = getInstructionHex(instrID);
            // Convert the hexadecimal instruction to binary
            String instrBin = hexToBin(instrHex);
            getInstruction(instrBin);
            //testPrint(i);
        }
        
    }
    
    public void getInstruction(String instrBin) {
        // Get first two bits of instruction to get format
        String twoBits = instrBin.substring(0, 2);
        switch (twoBits) {
            // Arithmetic Instruction Format
            case "00":
                getArithmeticInstruction(instrBin);
                break;
            // Conditional Branch and Immediate Format
            case "01":
                getConditionalInstruction(instrBin);
                break;
            // Unconditional Jump Format
            case "10":
                break;
            // Input and Output Instruction Format
            case "11":
                break;
        }
    }
    
    private void getArithmeticInstruction(String instrBin) {
        //     2        6       4      4      4     12 
        String twoBits, OPCODE, SReg1, SReg2, DReg, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        SReg1 = instrBin.substring(8, 12);
        SReg2 = instrBin.substring(12, 16);
        DReg = instrBin.substring(16, 20);
        address = instrBin.substring(20);
        
        ArithmeticInstruction instrA = new ArithmeticInstruction(twoBits, OPCODE,
                                                                SReg1, SReg2,
                                                                DReg, address);
        instructions.add(instrA);
    }
    
    private void getConditionalInstruction(String instrBin) {
        //     2        6       4     4     16
        String twoBits, OPCODE, BReg, DReg, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        BReg = instrBin.substring(8, 12);
        DReg = instrBin.substring(12, 16);
        address = instrBin.substring(16);
        
        ConditionalInstruction instrC = new ConditionalInstruction(twoBits, OPCODE, BReg,
                                                                    DReg, address);
        instructions.add(instrC);
    }
    
    private void getUnconditionalInstruction(String instrBin) {
        
    }
    
    public static String getInstructionType(String OPCODE) {
        String instructionType = "";
        switch (OPCODE) {
            case "0":
                instructionType = "RD";
                break;
            case "01":
            case "1":
                instructionType = "WR";
                break;
            case "02":
            case "2":
                instructionType = "ST";
                break;
            case "03":
            case "3":
                instructionType = "LW";
                break;
            case "04":
            case "4":
                instructionType = "MOV";
                break;
            case "05":
            case "5":
                instructionType = "ADD";
                break;
            case "06":
            case "6":
                instructionType = "SUB";
                break;
            case "07":
            case "7":
                instructionType = "MUL";
                break;
            case "08":
            case "8":
                instructionType = "DIV";
                break;
            case "09":
            case "9":
                instructionType = "AND";
                break;
            case "0A":
                instructionType = "OR";
                break;
            case "0B":
                instructionType = "MOVI";
                break;
            case "0C":
                instructionType = "ADDI";
                break;
            case "0D":
                instructionType = "MULI";
                break;
            case "0E":
                instructionType = "DIVI";
                break;
            case "0F":
                instructionType = "LDI";
                break;
            case "10":
                instructionType = "SLT";
                break;
            case "11":
                instructionType = "SLTI";
                break;
            case "12":
                instructionType = "HLT";
                break;
            case "13":
                instructionType = "NOP";
                break;
            case "14":
                instructionType = "JMP";
                break;
            case "15":
                instructionType = "BEQ";
                break;
            case "16":
                instructionType = "BNE";
                break;
            case "17":
                instructionType = "BEZ";
                break;
            case "18":
                instructionType = "BNZ";
                break;
            case "19":
                instructionType = "BGZ";
                break;
            case "1A":
                instructionType = "BLZ";
                break;
        }
        return instructionType;
    }
    
    public void testPrint(int i) {
        String instruction = job.instructions.get(i);
        System.out.println("************  " + i + ". Instruction: " + instruction + "  ************");
        
        String hex = getInstructionHex(instruction);
        System.out.println("Hexadecimal: " + hex + "\n");
        
        String bin = hexToBin(hex);
        System.out.println("HEXADECIMAL TO BINARY");
        System.out.println("Binary: " + bin);
        System.out.println("2 bits: " + bin.substring(0, 2) + "\n");
        
        String OPCODE_bin = bin.substring(2, 8);
        System.out.println("OPCODE (Binary): " + OPCODE_bin);
        String OPCODE_hex = binToHex(OPCODE_bin);
        System.out.println("OPCODE (Hexadecimal): " + OPCODE_hex);
        System.out.println("OPCODE Instruction type: " + getInstructionType(OPCODE_hex)
                + "\n");
        
        System.out.println("Reg 1: " + bin.substring(8, 12));
        System.out.println("Reg 2: " + bin.substring(12, 16));
        System.out.println("Address: " + bin.substring(16));
        System.out.println("************  END OF INSTRUCTION  ************\n");
    }
    
    public static String getInstructionHex(String instruction) {
        return instruction.substring(2);
    }
    
    public static String binToHex(String binStr) {
        int bin = Integer.parseInt(binStr, 2);
        return Integer.toString(bin, 16);
    }
    
    public static String hexToBin(String hex) {
        return new BigInteger(hex, 16).toString(2);
    }
    
    public static String binToDec(String bin) {
        int dec = Integer.parseInt(bin, 2);
        return Integer.toString(dec);
    }
    
    
    public void printJobs() {
        System.out.println("********  FROM CPU  ********");
        System.out.println("JOB 1");
        job.printJob();
        System.out.println("********  FROM CPU  ********");
    }
}
