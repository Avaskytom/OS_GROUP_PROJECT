/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

public class CPU {
    Job job = new Job();
    
    CPU () {}
    
    public void fetch(Job job) {
        this.job = job;
    }
    
    public void decode() {
        
    }
    
    public void testPrint() {
        String instruction = job.instructions.get(0);
        System.out.println("Instruction: " + instruction + "\n");
        
        String hex = getInstructionHex(instruction);
        System.out.println("Hexadecimal: " + hex + "\n");
        
        String bin = hexToBin(hex);
        System.out.println("HEXADECIMAL TO BINARY");
        System.out.println("Binary: " + bin);
        System.out.println("2 bits: " + bin.substring(0, 2) + "\n");
        
        String OPCODE_bin = bin.substring(2, 8);
        System.out.println("OPCODE (Binary): " + OPCODE_bin);
        String OPCODE_hex = binToHex(OPCODE_bin);
        System.out.println("OPCODE (Hexadecimal): " + OPCODE_hex);
        System.out.println("OPCODE Instruction type: " + getInstructionType(OPCODE_hex)
                + "\n");
        
        System.out.println("Reg 1: " + bin.substring(8, 12));
        System.out.println("Reg 2: " + bin.substring(12, 16));
        System.out.println("Address: " + bin.substring(16));
    }
    
    public void printJobs() {
        System.out.println("********  FROM CPU  ********");
        System.out.println("JOB 1");
        job.printJob();
        System.out.println("********  FROM CPU  ********");
    }
}
