/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.math.BigInteger;
import java.util.ArrayList;

public class CPU {
    Job job = new Job();
    ArrayList<Instruction> instructions = new ArrayList<>();
    
    CPU () {}
    
    public void fetch(Job job) {
        this.job = job;
    }
    
    public void decode() {
        
        for (int i = 0; i < job.instructions.size(); i++) {
            // Get the string of the instruction
            String instrID = job.instructions.get(i);
            // Convert the instruction to hexadecimal
            String instrHex = getInstructionHex(instrID);
            // Convert the hexadecimal instruction to binary
            String instrBin = hexToBin(instrHex);
            getInstruction(instrBin);
            //testPrint(i);
        }
        
    }
    
    public void getInstruction(String instrBin) {
        // Get first two bits of instruction to get format
        String twoBits = instrBin.substring(0, 2);
        switch (twoBits) {
            // Arithmetic Instruction Format
            case "00":
                getArithmeticInstruction(instrBin);
                break;
            // Conditional Branch and Immediate Format
            case "01":
                getConditionalInstruction(instrBin);
                break;
            // Unconditional Jump Format
            case "10":
                getUnconditionalInstruction(instrBin);
                break;
            // Input and Output Instruction Format
            case "11":
                getIOInstruction(instrBin);
                break;
        }
    }
    
    private void getArithmeticInstruction(String instrBin) {
        //     2        6       4      4      4     12 
        String twoBits, OPCODE, SReg1, SReg2, DReg, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        SReg1 = instrBin.substring(8, 12);
        SReg2 = instrBin.substring(12, 16);
        DReg = instrBin.substring(16, 20);
        address = instrBin.substring(20);
        
        ArithmeticInstruction instrA = new ArithmeticInstruction(twoBits, OPCODE,
                                                                SReg1, SReg2,
                                                                DReg, address);
        instructions.add(instrA);
    }
    
    private void getConditionalInstruction(String instrBin) {
        //     2        6       4     4     16
        String twoBits, OPCODE, BReg, DReg, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        BReg = instrBin.substring(8, 12);
        DReg = instrBin.substring(12, 16);
        address = instrBin.substring(16);
        
        ConditionalInstruction instrC = new ConditionalInstruction(twoBits, OPCODE, BReg,
                                                                    DReg, address);
        instructions.add(instrC);
    }
    
    private void getUnconditionalInstruction(String instrBin) {
        String twoBits, OPCODE, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        address = instrBin.substring(8);
        
        UnconditionalInstruction instrU = new UnconditionalInstruction(twoBits, OPCODE, address);
        instructions.add(instrU);
    }
    
    private void getIOInstruction(String instrBin) {
        String twoBits, OPCODE, reg1, reg2, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        reg1 = instrBin.substring(8, 12);
        reg2 = instrBin.substring(12, 16);
        address = instrBin.substring(16);
        
        IOInstruction instrIO = new IOInstruction(twoBits, OPCODE, reg1,
                                                                reg2, address);
        instructions.add(instrIO);
    }
    
    public void printInstructions() {
        
    }
    
    public void testPrint(int i) {
        String instruction = job.instructions.get(i);
        System.out.println("************  " + i + ". Instruction: " + instruction + "  ************");
        
        String hex = getInstructionHex(instruction);
        System.out.println("Hexadecimal: " + hex + "\n");
        
        String bin = hexToBin(hex);
        System.out.println("HEXADECIMAL TO BINARY");
        System.out.println("Binary: " + bin);
        System.out.println("2 bits: " + bin.substring(0, 2) + "\n");
        
        String OPCODE_bin = bin.substring(2, 8);
        System.out.println("OPCODE (Binary): " + OPCODE_bin);
        String OPCODE_hex = binToHex(OPCODE_bin);
        System.out.println("OPCODE (Hexadecimal): " + OPCODE_hex);
        
        System.out.println("Reg 1: " + bin.substring(8, 12));
        System.out.println("Reg 2: " + bin.substring(12, 16));
        System.out.println("Address: " + bin.substring(16));
        System.out.println("************  END OF INSTRUCTION  ************\n");
    }
    
    public static String getInstructionHex(String instruction) {
        return instruction.substring(2);
    }
    
    public static String binToHex(String binStr) {
        int bin = Integer.parseInt(binStr, 2);
        return Integer.toString(bin, 16);
    }
    
    public static String hexToBin(String hex) {
        return new BigInteger(hex, 16).toString(2);
    }
    
    public static String binToDec(String bin) {
        int dec = Integer.parseInt(bin, 2);
        return Integer.toString(dec);
    }
    
    
    public void printJobs() {
        System.out.println("********  FROM CPU  ********");
        System.out.println("JOB 1");
        job.printJob();
        System.out.println("********  FROM CPU  ********");
    }
}
