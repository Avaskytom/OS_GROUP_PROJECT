/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 01
public class ConditionalInstruction extends Instruction {
    String twoBits, OPCODE, BReg, DReg, address;
    
    public ConditionalInstruction() {}
    
    public ConditionalInstruction(String twoBits, String OPCODE,
                                String BReg, String DReg,
                                String address) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.BReg = BReg;
        this.DReg = DReg;
        this.address = address;
        
        getInstructionType(OPCODE);
    }
}
