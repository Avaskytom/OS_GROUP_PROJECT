/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 11
public class IOInstruction extends Instruction {
    String twoBits, OPCODE, reg1, reg2, address;
    
    public IOInstruction () {}
    
    public IOInstruction (String twoBits, String OPCODE,
                        String reg1, String reg2,
                        String address) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.reg1 = reg1;
        this.reg2 = reg2;
        this.address = address;
        
        getInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        System.out.println("********  INPUT OUTPUT  ********"
                        + "2 bits: " + twoBits + "\n"
                        + "OPCODE: " + OPCODE + "\n"
                        + "Reg1: " + reg1 + "\n"
                        + "Reg2: " + reg2 + "\n"
                        + "Address: " + address + "\n");
    }
}
