/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Disk {
    ArrayList<Job> UnsortedJobs = new ArrayList<Job>();
    
    public void setJobs(ArrayList Jobs) {
        UnsortedJobs.addAll(Jobs);
    }
}
