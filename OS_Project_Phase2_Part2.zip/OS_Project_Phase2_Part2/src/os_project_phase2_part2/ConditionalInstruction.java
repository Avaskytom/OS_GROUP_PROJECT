/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 01
public class ConditionalInstruction extends Instruction {
    String twoBits, OPCODE, BReg, DReg, address;
    String instrType, instrHex;
    
    public ConditionalInstruction() {}
    
    public ConditionalInstruction(String twoBits, String OPCODE,
                                String BReg, String DReg,
                                String address, String instrHex) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.BReg = BReg;
        this.DReg = DReg;
        this.address = address;
        this.instrHex = instrHex;
        instrType = setInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        //System.out.println("\tCONDITIONAL\n");
        //System.out.println("\tInstruction Type: " + setInstructionType(OPCODE) + "\n");
        System.out.println("\t" + instrHex);
    }
    
    public String getInstructionType() {
        return instrType;
    }
}
