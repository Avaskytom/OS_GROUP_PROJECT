/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 *
 * This is the core component of the whole system.
 * 
 */
package os_project_phase2_part2;

/*
 * Driver calls:
 * Loader
 * Long Scheduler
 * Short Scheduler
 */
public class Driver {
    
    public Driver() {
        // 1. Call the Loader first
        Loader loader = new Loader();
        String fileName = "src\\os_project_phase2_part2\\ProgramFile-TextVersion.txt";
        
        // 2. Read the jobs from the program file
        Disk disk = new Disk();
        
        // 3. Load the jobs onto the disk
        loader.load(disk, fileName);
        
        // 4. Memory is created, ready to store jobs
        Memory memory = new Memory();
        
        // 5. Call the Long Scheduler to sort the jobs from Disk
        LongScheduler longScheduler = new LongScheduler();
        longScheduler.loadFromDisk(disk);
        
        // 6. Load the sorted jobs into Memory
        longScheduler.loadToMemory(memory);
        
        // 7. Call Short Scheduler to take five jobs from Memory
        ShortScheduler shortScheduler = new ShortScheduler();
        shortScheduler.loadFromMemory(memory);
        
        // 8. Short Scheduler sends jobs to PCB, then to Dispatcher
        PCB pcb = new PCB();
        shortScheduler.loadToPCB(pcb);
        Dispatcher dispatcher = new Dispatcher();
        dispatcher.extract(pcb);
        
        // 9. Dispatcher sends PCB back to OS Driver
        
        
        dispatcher.printJobs();
        memory.printJobs();
        
        
        /* After the loader is done, loop these components
        while (true) {
            LongScheduler(); // Takes the jobs from disk and sorts them
            
            Dispatcher();
            CPU();
            waitforinterrupt();
        }
        */
    }
        
}
