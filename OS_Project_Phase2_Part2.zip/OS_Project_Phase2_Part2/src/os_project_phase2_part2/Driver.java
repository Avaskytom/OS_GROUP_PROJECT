/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 *
 * This is the core component of the whole system.
 */
package os_project_phase2_part2;

public class Driver {
    
    public Driver() {
        long start = System.currentTimeMillis();
        Loader loader = new Loader();
        Disk disk = new Disk();
        Memory memory = new Memory();
        LongScheduler longScheduler = new LongScheduler();
        ShortScheduler shortScheduler = new ShortScheduler();
        PCB pcb = new PCB();
        Dispatcher dispatcher = new Dispatcher();
        CPU cpu = new CPU();
        String fileName = "src\\os_project_phase2_part2\\ProgramFile-TextVersion.txt";
        
        loader.load(disk, fileName);
        MemorySystem mmu = new MemorySystem(disk, memory);
        
        //while (!mmu.disk.Jobs.isEmpty()) {
            longScheduler.sortSJF(mmu);
            shortScheduler.loadFromDisk(mmu);
        while (!mmu.disk.Jobs.isEmpty()) {
            shortScheduler.loadToPCB(pcb);
            
            //while (!dispatcher.RQ.isEmpty()) {
            dispatcher.extract(pcb);
            dispatcher.assign(cpu);
            cpu.decode();
            cpu.execute();
            //}
            shortScheduler.loadFromDisk(mmu);
        }
        long finish = System.currentTimeMillis();
        long timeElapsed = finish - start;
        System.out.println("Elapsed time: " + timeElapsed + " milliseconds\n");
    }
}
