/*
 * This is the core component of the whole system.
 * 
 */
package os_project_phase2_part2;

/*
 * Driver calls:
 * Loader
 * Long Scheduler
 * Short Scheduler
 */
public class Driver {
    
    public Driver() {
        // 1. Call the Loader(); first
        Disk disk = new Disk();
        Loader loader = new Loader(disk);
        //disk.printJobs();
        LongScheduler longScheduler = new LongScheduler(disk);
        
        
        /* After the loader is done, loop these components
        while (true) {
            LongScheduler(); // Takes the jobs from disk and sorts them
            
            Dispatcher();
            CPU();
            waitforinterrupt();
        }
        */
    }
        
}
