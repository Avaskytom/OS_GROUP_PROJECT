/*
 * This is the core component of the whole system.
 * 
 */
package os_project_phase2_part2;

/*
 * Driver calls:
 * Loader
 * Long Scheduler
 * Short Scheduler
 */
public class Driver {
    
    public Driver() {
        // 1. Call the Loader(); first
        Loader loader = new Loader();
        Disk disk = new Disk();
        loader.load(disk);
        disk.printJobs();
        
        /* After the loader is done, loop these components
        while (true) {
            scheduler();
            dispatcher();
            CPU();
            waitforinterrupt();
        }
        */
    }
        
}
