/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;

/**
 *
 * @author Olivier
 */
public class MemorySystem {
    Disk disk = new Disk();
    Memory memory = new Memory();
    
    public MemorySystem() {}
    
    public MemorySystem(Disk disk, Memory memory) {
        this.disk = disk;
        this.memory = memory;
    }
}
