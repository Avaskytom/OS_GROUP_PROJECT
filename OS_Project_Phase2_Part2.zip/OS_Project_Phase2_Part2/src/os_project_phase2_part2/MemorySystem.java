/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;

/**
 *
 * @author Olivier
 */
public class MemorySystem {
    Disk disk = new Disk();
    Memory memory = new Memory();
    ArrayList<Job> SortedJobs = new ArrayList<>();
    
    public MemorySystem() {}
    
    public void setJobs(ArrayList SortedJobs) {
        this.SortedJobs.addAll(SortedJobs);
    }
}
