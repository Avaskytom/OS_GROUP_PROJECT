package os_project_phase2_part2;

import java.util.ArrayList;

public class ShortScheduler {
    ArrayList<Job> SortedJobs = new ArrayList<>();
    
    public void loadFromLongScheduler() {
        
    }
}
