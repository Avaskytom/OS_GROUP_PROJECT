/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;
import java.util.Collections;

public class ShortScheduler {
    ArrayList<Job> UnsortedJobs = new ArrayList<>();
    ArrayList<Job> SortedJobs = new ArrayList<>();
    
    ShortScheduler() {}
    
    public void loadFromDisk(MemorySystem mmu) {
        //UnsortedJobs.add(mmu.disk.Jobs.remove(0));
        //mmu.disk.printJobs();
        /*
        int i = 0;
        while (!mmu.disk.Jobs.isEmpty() && i < 5) {
            UnsortedJobs.add(mmu.disk.Jobs.remove(i));
            i++;
        }
        */
        for (int i = 0; i < 5; i++) {
            UnsortedJobs.add(mmu.disk.Jobs.remove(i));
        }
        sortSJF();
    }
    public void loadFromMemory(Memory memory) {
        for (int i = 0; i < 5; i++) {
            UnsortedJobs.add(memory.SortedJobs.remove(i));
        }
        sortSJF();
    }
    
    public void loadToPCB(PCB pcb) {
        pcb.setJobs(SortedJobs);
        SortedJobs.clear();
    }
    // This is where the jobs are sorted by SJF
    private void sortPriority() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.priorityInt.compareTo(b.priorityInt));
    }
    
    private void sortSJF() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.numWordsInt.compareTo(b.numWordsInt));
    }
    
    public void printJobs() {
        System.out.println("FROM SHORT SCHEDULER\n");
        for (int i = 0; i < SortedJobs.size(); i++) {
            System.out.println("JOB " + (i + 1));
            SortedJobs.get(i).printJob();
        }
        System.out.println("FROM SHORT SCHEDULER\n");
    }
}
