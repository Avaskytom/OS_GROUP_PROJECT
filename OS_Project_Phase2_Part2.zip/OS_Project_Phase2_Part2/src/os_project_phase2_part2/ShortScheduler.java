/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;
import java.util.Collections;

public class ShortScheduler {
    ArrayList<Job> UnsortedJobs = new ArrayList<>();
    ArrayList<Job> SortedJobs = new ArrayList<>();
    
    ShortScheduler() {}
    
    public void loadFromMemory(Memory memory) {
        for (int i = 0; i < 5; i++) {
            UnsortedJobs.add(memory.SortedJobs.remove(i));
        }
        sort();
    }
    
    private void sort() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.priorityInt.compareTo(b.priorityInt));
    }
    
    public void printJobs() {
        for (int i = 0; i < SortedJobs.size(); i++) {
            System.out.println("JOB " + (i + 1));
            SortedJobs.get(i).printJob();
        }
        System.out.println("FROM SHORT SCHEDULER");
    }
}
