/*
 * @authors:
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.math.BigInteger;

public class OS_Project_Phase2_Part2 {

    public static void main(String[] args) {
        // Call the driver
        Driver driver = new Driver();
    }
    
}
