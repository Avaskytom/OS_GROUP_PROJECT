/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 10
public class UnconditionalInstruction extends Instruction {
    String twoBits, OPCODE, address;
    String instrType;
    
    public UnconditionalInstruction () {}
    
    public UnconditionalInstruction (String twoBits, String OPCODE,
                                    String address) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.address = address;
        
        instrType = setInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        System.out.println("\t********  UNCONDITIONAL  ********\n"
                        + "\t2 bits: " + twoBits + "\n"
                        + "\tOPCODE: " + OPCODE + "\n"
                        + "\tInstruction Type: " + setInstructionType(OPCODE) + "\n"
                        + "\tAddress: " + address + "\n");
    }
    
    public String getInstructionType() {
        return instrType;
    }
}
