/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 10
public class UnconditionalInstruction extends Instruction {
    String twoBits, OPCODE, address;
    String instrType, instrHex;
    
    public UnconditionalInstruction () {}
    
    public UnconditionalInstruction (String twoBits, String OPCODE,
                                    String address, String instrHex) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.address = address;
        this.instrHex = instrHex;
        instrType = setInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        //System.out.println("\tUNCONDITIONAL\n");
        //System.out.println("\tInstruction Type: " + setInstructionType(OPCODE) + "\n");
        System.out.println("\t" + instrHex);
    }
    
    public String getInstructionType() {
        return instrType;
    }
}
