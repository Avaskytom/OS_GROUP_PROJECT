/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.math.BigInteger;
import java.util.ArrayList;

public class CPU {
    Job job = new Job();
    ArrayList<Instruction> instructions = new ArrayList<>();
    ArrayList<Instruction> dataInstructions = new ArrayList<>();
    int pc = 0; // The program counter
    
    CPU () {}
    
    public void fetch(Job job) {
        this.job = job;
    }
    
    public void decode() {
        for (int i = 0; i < job.instructions.size(); i++) {
            // Get the string of the instruction
            String instrID = job.instructions.get(i);
            // Convert the instruction to hexadecimal
            String instrHex = getInstructionHex(instrID);
            // Convert the hexadecimal instruction to binary
            String instrBin = hexToBin(instrHex);
            getInstruction(instrBin, instrHex);
            
            String dataInstrID = job.dataInstructions.get(i);
            String dataInstrHex = getInstructionHex(dataInstrID);
            String dataInstrBin = hexToBin(dataInstrHex);
            while (dataInstrBin.length() < 20) {
                dataInstrBin = "0" + dataInstrBin;
            }
            getDataInstruction(dataInstrBin, dataInstrHex);
            
        }        
    }
    
    public void execute() {
        System.out.println("Job " + job.jobID + " " + job.numWordsInt + " " + job.priorityInt);
        printInstructions();
    }
    
    public void getInstruction(String instrBin, String instrHex) {
        // Get first two bits of instruction to get format
        String twoBits = instrBin.substring(0, 2);
        switch (twoBits) {
            // Arithmetic Instruction Format
            case "00":
                getArithmeticInstruction(instrBin, instrHex);
                break;
            // Conditional Branch and Immediate Format
            case "01":
                getConditionalInstruction(instrBin, instrHex);
                break;
            // Unconditional Jump Format
            case "10":
                getUnconditionalInstruction(instrBin, instrHex);
                break;
            // Input and Output Instruction Format
            case "11":
                getIOInstruction(instrBin, instrHex);
                break;
        }
    }
    private void getArithmeticInstruction(String instrBin, String instrHex) {
        //     2        6       4      4      4     12 
        String twoBits, OPCODE, SReg1, SReg2, DReg, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        SReg1 = instrBin.substring(8, 12);
        SReg2 = instrBin.substring(12, 16);
        DReg = instrBin.substring(16, 20);
        address = instrBin.substring(20);
        
        ArithmeticInstruction instrA = new ArithmeticInstruction(twoBits, OPCODE,
                                                                SReg1, SReg2,
                                                                DReg, address, instrHex);
        instructions.add(instrA);
    }
    private void getConditionalInstruction(String instrBin, String instrHex) {
        //     2        6       4     4     16
        String twoBits, OPCODE, BReg, DReg, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        BReg = instrBin.substring(8, 12);
        DReg = instrBin.substring(12, 16);
        address = instrBin.substring(16);
        
        ConditionalInstruction instrC = new ConditionalInstruction(twoBits, OPCODE, BReg,
                                                                    DReg, address, instrHex);
        instructions.add(instrC);
    }
    private void getUnconditionalInstruction(String instrBin, String instrHex) {
        String twoBits, OPCODE, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        address = instrBin.substring(8);
        
        UnconditionalInstruction instrU = new UnconditionalInstruction(twoBits, OPCODE, address, instrHex);
        instructions.add(instrU);
    }
    private void getIOInstruction(String instrBin, String instrHex) {
        String twoBits, OPCODE, reg1, reg2, address;
        
        twoBits = instrBin.substring(0, 2);
        OPCODE = instrBin.substring(2, 8);
        reg1 = instrBin.substring(8, 12);
        reg2 = instrBin.substring(12, 16);
        address = instrBin.substring(16);
        
        IOInstruction instrIO = new IOInstruction(twoBits, OPCODE, reg1,
                                                                reg2, address, instrHex);
        instructions.add(instrIO);
    }
    
    public void getDataInstruction(String dataInstrBin, String dataInstrHex) {
        // Get first two bits of instruction to get format
        String twoBits = dataInstrBin.substring(0, 2);
        switch (twoBits) {
            // Arithmetic Instruction Format
            case "00":
                getArithmeticDataInstruction(dataInstrBin, dataInstrHex);
                break;
            // Conditional Branch and Immediate Format
            case "01":
                getConditionalDataInstruction(dataInstrBin, dataInstrHex);
                break;
            // Unconditional Jump Format
            case "10":
                getUnconditionalDataInstruction(dataInstrBin, dataInstrHex);
                break;
            // Input and Output Instruction Format
            case "11":
                getIODataInstruction(dataInstrBin, dataInstrHex);
                break;
        }
    }
    private void getArithmeticDataInstruction(String dataInstrBin, String dataInstrHex) {
        //     2        6       4      4      4     12 
        String twoBits, OPCODE, SReg1, SReg2, DReg, address;
        
        twoBits = dataInstrBin.substring(0, 2);
        OPCODE = dataInstrBin.substring(2, 8);
        SReg1 = dataInstrBin.substring(8, 12);
        SReg2 = dataInstrBin.substring(12, 16);
        DReg = dataInstrBin.substring(16, 20);
        address = dataInstrBin.substring(20);
        
        ArithmeticInstruction dataInstrA = new ArithmeticInstruction(twoBits, OPCODE,
                                                                SReg1, SReg2,
                                                                DReg, address, dataInstrHex);
        instructions.add(dataInstrA);
    }
    private void getConditionalDataInstruction(String dataInstrBin, String dataInstrHex) {
        //     2        6       4     4     16
        String twoBits, OPCODE, BReg, DReg, address;
        
        twoBits = dataInstrBin.substring(0, 2);
        OPCODE = dataInstrBin.substring(2, 8);
        BReg = dataInstrBin.substring(8, 12);
        DReg = dataInstrBin.substring(12, 16);
        address = dataInstrBin.substring(16);
        
        ConditionalInstruction dataInstrC = new ConditionalInstruction(twoBits, OPCODE, BReg,
                                                                    DReg, address, dataInstrHex);
        instructions.add(dataInstrC);
    }
    private void getUnconditionalDataInstruction(String dataInstrBin, String dataInstrHex) {
        String twoBits, OPCODE, address;
        
        twoBits = dataInstrBin.substring(0, 2);
        System.out.println("bin: " + dataInstrBin);
        System.out.println("hex: " + dataInstrHex);
        OPCODE = dataInstrBin.substring(2, 8);
        address = dataInstrBin.substring(8);
        
        UnconditionalInstruction dataInstrU = new UnconditionalInstruction(twoBits, OPCODE, address, dataInstrHex);
        instructions.add(dataInstrU);
    }
    private void getIODataInstruction(String dataInstrBin, String dataInstrHex) {
        String twoBits, OPCODE, reg1, reg2, address;
        
        twoBits = dataInstrBin.substring(0, 2);
        OPCODE = dataInstrBin.substring(2, 8);
        reg1 = dataInstrBin.substring(8, 12);
        reg2 = dataInstrBin.substring(12, 16);
        address = dataInstrBin.substring(16);
        
        IOInstruction dataInstrIO = new IOInstruction(twoBits, OPCODE, reg1,
                                                                reg2, address, dataInstrHex);
        instructions.add(dataInstrIO);
    }
    
    public void printInstructions() {
        System.out.println("\tINSTRUCTIONS");
        for (int i = 0; i < instructions.size(); i++) {
            //System.out.print("\tINSTRUCTION " + (i + 1));
            instructions.get(i).printInstruction();
        }
        System.out.println("\tDATA INSTRUCTIONS");
        for (int i = 0; i < dataInstructions.size(); i++) {
            //System.out.print("\tDATA INSTRUCTION " + (i + 1));
            dataInstructions.get(i).printInstruction();
        }
        System.out.println();
    }
    
    public static String getInstructionHex(String instruction) {
        return instruction.substring(2);
    }
    public static String binToHex(String binStr) {
        int bin = Integer.parseInt(binStr, 2);
        return Integer.toString(bin, 16);
    }
    public static String hexToBin(String hex) {
        return new BigInteger(hex, 16).toString(2);
    }
    public static String binToDec(String bin) {
        int dec = Integer.parseInt(bin, 2);
        return Integer.toString(dec);
    }
    
    
    public void printJobs() {
        System.out.println("********  FROM CPU  ********");
        System.out.println("JOB 1");
        job.printJob();
        System.out.println("********  FROM CPU  ********");
    }
}
