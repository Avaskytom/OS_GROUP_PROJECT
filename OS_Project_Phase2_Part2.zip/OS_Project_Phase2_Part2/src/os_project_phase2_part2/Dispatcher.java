/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;

public class Dispatcher {
    ArrayList<Job> RQ = new ArrayList<>();
    
    Dispatcher() {}
    
    public void extract(PCB pcb) {
        RQ.addAll(pcb.Jobs);
        pcb.Jobs.clear();
    }
    
    public void assign(CPU cpu) {
        Job job = RQ.remove(0);
        cpu.fetch(job);
        
    }
    
    public void printJobs() {
        System.out.println("********  FROM DISPATCHER  ********");
        for (int i = 0; i < RQ.size(); i++) {
            System.out.println("JOB " + (i + 1));
            RQ.get(i).printJob();
        }
        System.out.println("********  FROM DISPATCHER  ********\n");
    }
}
