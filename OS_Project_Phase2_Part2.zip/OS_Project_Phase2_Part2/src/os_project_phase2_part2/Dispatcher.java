/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;

public class Dispatcher {
    ArrayList<Job> RQ = new ArrayList<>();
    
    Dispatcher() {}
    
    
}
