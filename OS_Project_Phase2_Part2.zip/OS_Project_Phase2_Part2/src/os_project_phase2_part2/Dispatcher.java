/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

/**
 *
 * @author Olivier
 */
public class Dispatcher {
    
}
