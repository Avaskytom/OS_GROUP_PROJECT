/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;

public class PCB {
    ArrayList<Job> Jobs = new ArrayList<>();
    
    public PCB() {}
    
    public void setJobs(ArrayList Jobs) {
        this.Jobs.addAll(Jobs);
    }
    
    public void printJobs() {
        System.out.println("FROM PCB\n");
        for (int i = 0; i < Jobs.size(); i++) {
            System.out.println("JOB " + (i + 1));
            Jobs.get(i).printJob();
        }
        System.out.println("FROM PCB\n");
    }
}
