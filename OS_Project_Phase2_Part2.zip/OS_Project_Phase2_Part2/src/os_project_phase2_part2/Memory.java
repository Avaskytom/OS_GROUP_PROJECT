package os_project_phase2_part2;

import java.util.ArrayList;

/*
 * Memory calls:
 * Disk
 */
public class Memory {
    
    public Memory() {}
    
    ArrayList<String> al = new ArrayList<String>();
    int inc = 0;
    
    public void insert(String line) {
        al.add(line);
        //inc++;
        //System.out.println("lines: " + inc);
        //System.out.println(line);        
    }
}
