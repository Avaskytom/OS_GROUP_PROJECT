/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;

public class Memory {
    int words = 1024;
    ArrayList<Job> SortedJobs = new ArrayList<>();
    
    public Memory() {}
    
    public void setJobs(ArrayList SortedJobs) {
        this.SortedJobs.addAll(SortedJobs);
    }
    
    public void printJobs() {
        System.out.println("********  FROM MEMORY  ********");
        for (int i = 0; i < SortedJobs.size(); i++) {
            System.out.println("JOB " + (i + 1));
            SortedJobs.get(i).printJob();
        }
        System.out.println("********  FROM MEMORY  ********\n");
    }
}
