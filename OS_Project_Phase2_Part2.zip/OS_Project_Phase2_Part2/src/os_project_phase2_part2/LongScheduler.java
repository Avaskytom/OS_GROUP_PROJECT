/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;
import java.util.Collections;

public class LongScheduler {
    ArrayList<Job> UnsortedJobs = new ArrayList<>();
    static ArrayList<Job> SortedJobs = new ArrayList<>();
    
    LongScheduler() {}
    
    public void loadFromDisk(Disk disk) {
        UnsortedJobs.addAll(disk.UnsortedJobs); // Load the jobs from disk to scheduler, unsorted.
        sortSJF();
    }
    
    public void loadToMemory(MemorySystem mmu) {
        mmu.setJobs(SortedJobs);
    }
    
    private void sortFIFO() {
        SortedJobs = UnsortedJobs;
    }
    // This is where the jobs are sorted by SJF
    private void sortPriority() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.priorityInt.compareTo(b.priorityInt));
    }
    
    private void sortSJF() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.numWordsInt.compareTo(b.numWordsInt));
    }
}
