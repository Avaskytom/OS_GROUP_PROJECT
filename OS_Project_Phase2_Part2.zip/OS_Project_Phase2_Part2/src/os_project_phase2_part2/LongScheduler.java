/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;
import java.util.Collections;

public class LongScheduler {
    ArrayList<Job> UnsortedJobs = new ArrayList<>();
    static ArrayList<Job> SortedJobs = new ArrayList<>();
    
    LongScheduler() {}
    
    public void loadFromDisk(Disk disk) {
        UnsortedJobs.addAll(disk.Jobs); // Load the jobs from disk to scheduler, unsorted.
        sortSJF();
    }
    
    public void sortFIFO(MemorySystem mmu) {
        
    }
    public void sortPriority(MemorySystem mmu) {
        Collections.sort(mmu.disk.Jobs, (a, b) -> a.priorityInt.compareTo(b.priorityInt));
    }
    
    public void sortSJF(MemorySystem mmu) {
        Collections.sort(mmu.disk.Jobs, (a, b) -> a.numWordsInt.compareTo(b.numWordsInt));
    }
    
    public void loadToMemory(Memory memory) {
        memory.setJobs(SortedJobs);
        //printJobs();
    }
    
    private void sortFIFO() {
        SortedJobs = UnsortedJobs;
    }
    // This is where the jobs are sorted by SJF
    private void sortPriority() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.priorityInt.compareTo(b.priorityInt));
    }
    
    private void sortSJF() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.numWordsInt.compareTo(b.numWordsInt));
    }
    
    public void printJobs() {
        System.out.println("FROM LONG SCHEDULER\n");
        for (int i = 0; i < SortedJobs.size(); i++) {
            System.out.println("JOB " + (i + 1));
            SortedJobs.get(i).printJob();
        }
        System.out.println("FROM LONG SCHEDULER\n");
    }
}
