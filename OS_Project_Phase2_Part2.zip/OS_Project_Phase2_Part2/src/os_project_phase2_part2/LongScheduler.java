/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.util.ArrayList;
import java.util.Collections;

public class LongScheduler {
    ArrayList<Job> UnsortedJobs = new ArrayList<>();
    static ArrayList<Job> SortedJobs = new ArrayList<>();
    
    LongScheduler() {}
    
    public void loadFromDisk(Disk disk) {
        UnsortedJobs.addAll(disk.UnsortedJobs); // Load the jobs from disk to scheduler, unsorted.
        sort();
    }
    // This is where the jobs are sorted by SJF
    private void sort() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.priorityInt.compareTo(b.priorityInt));
    }
    
    public void loadToMemory(Memory memory) {
        memory.setJobs(SortedJobs);
    }
}
