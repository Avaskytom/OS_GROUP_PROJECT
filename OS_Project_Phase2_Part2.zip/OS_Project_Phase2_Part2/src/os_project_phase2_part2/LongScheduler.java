package os_project_phase2_part2;

import java.util.ArrayList;
import java.util.Collections;

public class LongScheduler {
    ArrayList<Job> UnsortedJobs = new ArrayList<>();
    static ArrayList<Job> SortedJobs = new ArrayList<>();
    Memory mem;
    
    LongScheduler(Disk disk) {
        loadFromDisk(disk);
        sort();
        mem = new Memory();
        //printJobs();
        loadToMemory(SortedJobs);
        mem.printJobs();
    }
    
    public void loadFromDisk(Disk disk) {
        UnsortedJobs.addAll(disk.UnsortedJobs); // Load the jobs from disk to scheduler, unsorted.
    }
    
    public void sort() {
        SortedJobs = UnsortedJobs;
        Collections.sort(SortedJobs, (a, b) -> a.priorityInt.compareTo(b.priorityInt));
        //printJobs();
    }
    
    public void loadToMemory(ArrayList Jobs) {
        this.mem.setJobs(Jobs);
        System.out.println("DEBUG");
    }
    
    public void printJobs() {
        for (int i = 0; i < UnsortedJobs.size(); i++) {
            //System.out.println("JOB " + (i + 1));
            UnsortedJobs.get(i).printJob();
        }
        System.out.println("FROM LONG SCHEDULER");
    }
}
