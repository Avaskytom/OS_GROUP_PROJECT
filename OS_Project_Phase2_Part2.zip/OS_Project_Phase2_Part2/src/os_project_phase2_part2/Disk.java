package os_project_phase2_part2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Disk {
    ArrayList<Job> Jobs = new ArrayList<Job>();
    
    public void setJob(ArrayList Jobs) {
        this.Jobs = Jobs;
    }
    
    public void printJobs() {
        for (int i = 0; i < Jobs.size(); i++) {
            System.out.println("JOB " + (i + 1));
            Jobs.get(i).printJob();
        }
    }
}
