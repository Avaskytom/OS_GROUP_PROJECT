package os_project_phase2_part2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Disk {
    ArrayList<Job> UnsortedJobs = new ArrayList<Job>();
    
    public void setJobs(ArrayList Jobs) {
        UnsortedJobs.addAll(Jobs);
    }
    
    public void printJobs() {
        System.out.println("FROM DISK");
        for (int i = 0; i < UnsortedJobs.size(); i++) {
            System.out.println("JOB " + (i + 1));
            UnsortedJobs.get(i).printJob();
        }
        System.out.println("FROM DISK");
    }
}
