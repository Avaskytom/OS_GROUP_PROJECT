/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Disk {
    int words = 2048;
    ArrayList<Job> Jobs = new ArrayList<>();
    
    public void setJobs(ArrayList Jobs) {
        this.Jobs.addAll(Jobs);
    }
    
    public void printJobs() {
        System.out.println("FROM DISK\n");
        for (int i = 0; i < Jobs.size(); i++) {
            System.out.println("JOB " + (i + 1));
            Jobs.get(i).printJob();
        }
        System.out.println("FROM DISK\n");
    }
}