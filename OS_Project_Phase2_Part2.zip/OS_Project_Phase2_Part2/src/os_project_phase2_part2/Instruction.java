/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;

public class Instruction {
    String instrType;
    
    public Instruction() {}
    
    public String setInstructionType(String OPCODE) {
        // Convert the OPCODE from binary to hexadecimal
        String instrType = binToHex(OPCODE);
        switch (instrType) {
            case "0":
                instrType =  "RD";
                break;
            case "01":
            case "1":
                instrType =  "WR";
                break;
            case "02":
            case "2":
                instrType =  "ST";
                break;
            case "03":
            case "3":
                instrType =  "LW";
                break;
            case "04":
            case "4":
                instrType =  "MOV";
                break;
            case "05":
            case "5":
                instrType =  "ADD";
                break;
            case "06":
            case "6":
                instrType =  "SUB";
                break;
            case "07":
            case "7":
                instrType =  "MUL";
                break;
            case "08":
            case "8":
                instrType =  "DIV";
                break;
            case "09":
            case "9":
                instrType =  "AND";
                break;
            case "0A":
                instrType =  "OR";
                break;
            case "0B":
                instrType =  "MOVI";
                break;
            case "0C":
                instrType =  "ADDI";
                break;
            case "0D":
                instrType =  "MULI";
                break;           
            case "0E":
                instrType =  "DIVI";
                break;           
            case "0F":
                instrType =  "LDI";
                break;
            case "10":
                instrType =  "SLT";
                break;
            case "11":
                instrType =  "SLTI";
                break;
            case "12":
                instrType =  "HLT";
                break;
            case "13":
                instrType =  "NOP";
                break;
            case "14":
                instrType =  "JMP";
                break;
            case "15":
                instrType =  "BEQ";
                break;
            case "16":
                instrType =  "BNE";
                break;
            case "17":
                instrType =  "BEZ";
                break;
            case "18":
                instrType =  "BNZ";
                break;
            case "19":
                instrType =  "BGZ";
                break;
            case "1A":
                instrType =  "BLZ";
                break;
            default:
                instrType = "unsuccessful";
        }
        return instrType;
    }
    
    public String binToHex(String binStr) {
        int bin = Integer.parseInt(binStr, 2);
        return Integer.toString(bin, 16);
    }
    
    public String getInstructionType() {
        return instrType;
    }
    
    public void printInstruction() {}
}
