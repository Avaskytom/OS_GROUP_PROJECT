/*
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase2_part2;
// Starts with 11
public class IOInstruction extends Instruction {
    String twoBits, OPCODE, reg1, reg2, address;
    String instrType, instrHex;
    
    public IOInstruction () {}
    
    public IOInstruction (String twoBits, String OPCODE,
                        String reg1, String reg2,
                        String address, String instrHex) {
        this.twoBits = twoBits;
        this.OPCODE = OPCODE;
        this.reg1 = reg1;
        this.reg2 = reg2;
        this.address = address;
        this.instrHex = instrHex;
        instrType = setInstructionType(OPCODE);
    }
    
    public void printInstruction() {
        //System.out.println("\tINPUT OUTPUT\n");
        //System.out.println("\tInstruction Type: " + setInstructionType(OPCODE) + "\n")
        System.out.println("\t" + instrHex);
    }
    
    public String getInstructionType() {
        return instrType;
    }
}
