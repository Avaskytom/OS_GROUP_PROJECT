package os_project_phase2_part2;

import java.util.ArrayList;

public class Job {
    String jobID;
    String numWordsHex;
    int numWordsInt;
    int priorityInt;
    ArrayList<String> instructions = new ArrayList<String>();
    
    int inputBuffer;
    int outputBuffer;
    int tempBuffer;
    ArrayList<String> dataInstructions = new ArrayList<String>();
    
    public Job() {}
    
    public Job(String jobID, String numWordsHex, String priorityStr) {
        this.jobID = jobID;
        this.numWordsHex = numWordsHex;
        numWordsInt = Integer.parseInt(numWordsHex, 16);
        priorityInt = Integer.parseInt(priorityStr, 16);
    }
    public int getPriority() {
        return this.priorityInt;
    }
    public void addInstruction(String instruction) {
        instructions.add(instruction);
    }
    
    public void addDataInstruction(String dataInstruction) {
        dataInstructions.add(dataInstruction);
    }
    public void setDataInfo(String inputBufferStr, String outputBufferStr, String tempBufferStr) {
        this.inputBuffer = Integer.parseInt(inputBufferStr, 16);
        this.outputBuffer = Integer.parseInt(outputBufferStr, 16);
        this.tempBuffer = Integer.parseInt(tempBufferStr, 16);
    }
    public void setInputBuffer(String inputBufferStr) {
        this.inputBuffer = Integer.parseInt(inputBufferStr, 16);
    }
    public void setOutputBuffer(String outputBufferStr) {
        this.outputBuffer = Integer.parseInt(outputBufferStr, 16);
    }
    public void setTempBuffer(String tempBufferStr) {
        this.tempBuffer = Integer.parseInt(tempBufferStr, 16);
    }
    
    public void printJob() {
        System.out.println("********  JOB  ********\n"
                        + "Job ID: " + jobID + "\n"
                        + "Number of Words: " + numWordsInt + "\n"
                        + "Priority: " + priorityInt + "\n"
                        + "Number of instructions: " + instructions.size() + "\n"
                        + "********  DATA  ********\n"
                        + "Input Buffer: " + inputBuffer + "\n"
                        + "Output Buffer: " + outputBuffer + "\n"
                        + "Temp Buffer: " + tempBuffer + "\n"
                        + "Number of data instructions: " + dataInstructions.size() + "\n"
                        + "********  END  ********\n");
    }
}
