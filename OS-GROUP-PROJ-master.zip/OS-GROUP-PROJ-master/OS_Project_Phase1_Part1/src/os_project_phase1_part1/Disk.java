package os_project_phase1_part1;

import java.util.ArrayList;

public class Disk {
    static ArrayList<Job> Jobs = new ArrayList<>();
    
    public Disk() {}
    
    public static void loadToDisk(ArrayList loadedJobs) {
        Jobs = loadedJobs;
    }
    
    public static ArrayList loadFromDisk() {
        return Jobs;
    }
    
}
