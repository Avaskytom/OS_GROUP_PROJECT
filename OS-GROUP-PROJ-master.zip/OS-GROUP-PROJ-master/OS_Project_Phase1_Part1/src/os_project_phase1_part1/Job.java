package os_project_phase1_part1;

import java.util.ArrayList;

public class Job {
    String jobID;
    String numWordsHex;
    int numWordsInt;
    int priorityInt;
    ArrayList<String> instructions = new ArrayList<String>();
    
    int inputBuffer;
    int outputBuffer;
    int tempBuffer;
    ArrayList<String> dataInstructions = new ArrayList<String>();
    
    public Job() {}
    
    public Job(String jobID, String numWordsHex, String priorityStr) {
        this.jobID = jobID;
        this.numWordsHex = numWordsHex;
        this.numWordsInt = Integer.parseInt(numWordsHex, 16);
        this.priorityInt = Integer.parseInt(priorityStr, 16);
    }
    public int getPriority() {
        return this.priorityInt;
    }
    public void addInstruction(String instruction) {
        this.instructions.add(instruction);
        System.out.println("helo?");
    }
    
    public void addDataInstruction(String dataInstruction) {
        this.dataInstructions.add(dataInstruction);
    }
    public void setDataInfo(String inputBufferStr, String outputBufferStr, String tempBufferStr) {
        this.inputBuffer = Integer.parseInt(inputBufferStr, 16);
        this.outputBuffer = Integer.parseInt(outputBufferStr, 16);
        this.tempBuffer = Integer.parseInt(tempBufferStr, 16);
    }
    public void setInputBuffer(String inputBufferStr) {
        this.inputBuffer = Integer.parseInt(inputBufferStr, 16);
    }
    public void setOutputBuffer(String outputBufferStr) {
        this.outputBuffer = Integer.parseInt(outputBufferStr, 16);
    }
    public void setTempBuffer(String tempBufferStr) {
        this.tempBuffer = Integer.parseInt(tempBufferStr, 16);
    }
}
/*
class DataSection {
    int inputBuffer;
    int outputBuffer;
    int tempBuffer;
    ArrayList<String> dataInstructions = new ArrayList<String>();
    
    public DataSection() {}
    
    public DataSection(String inputBufferStr, String outputBufferStr, String tempBufferStr) {
        this.inputBuffer = Integer.parseInt(inputBufferStr, 16);
        this.outputBuffer = Integer.parseInt(outputBufferStr, 16);
        this.tempBuffer = Integer.parseInt(tempBufferStr, 16);
    }
    
    public void addDataInstruction(String dataInstruction) {
        this.dataInstructions.add(dataInstruction);
    }

}
*/
