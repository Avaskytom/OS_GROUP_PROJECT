package os_project_phase1_part1;

public class CPU {
    
    /*
    Fetch() {}
    Decode() {}
    Execute() {}
    */
    
}
