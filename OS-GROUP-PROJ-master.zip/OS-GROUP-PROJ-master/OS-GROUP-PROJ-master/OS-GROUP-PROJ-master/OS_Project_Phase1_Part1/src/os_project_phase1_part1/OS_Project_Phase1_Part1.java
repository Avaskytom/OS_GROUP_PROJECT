/*
 * @authors:
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase1_part1;

import java.math.BigInteger;

public class OS_Project_Phase1_Part1 {

    public static void main(String[] args) {
        // CALL THE DRIVER
        Driver driver = new Driver();
        
        //testPrint();
        
    }
    
    public static void testPrint() {
        String instruction = "0x4C060001";
        System.out.println("Instruction: " + instruction + "\n");
        
        String hex = getInstructionHex(instruction);
        System.out.println("Hexadecimal: " + hex + "\n");
        
        String bin = hexToBin(hex);
        System.out.println("HEXADECIMAL TO BINARY");
        System.out.println("Binary: " + bin);
        System.out.println("2 bits: " + bin.substring(0, 2) + "\n");
        
        String OPCODE_bin = bin.substring(2, 8);
        System.out.println("OPCODE (Binary): " + OPCODE_bin);
        String OPCODE_hex = binToHex(OPCODE_bin);
        System.out.println("OPCODE (Hexadecimal): " + OPCODE_hex);
        System.out.println("OPCODE Instruction type: " + getInstructionType(OPCODE_hex)
                + "\n");
        
        System.out.println("Reg 1: " + bin.substring(8, 12));
        System.out.println("Reg 2: " + bin.substring(12, 16));
        System.out.println("Address: " + bin.substring(16));
    }
    
    public static String getInstructionHex(String instruction) {
        return instruction.substring(2);
    }
    
    public static String binToHex(String binStr) {
        int bin = Integer.parseInt(binStr, 2);
        return Integer.toString(bin, 16);
    }
    
    public static String hexToBin(String hex) {
        return new BigInteger(hex, 16).toString(2);
    }
    
    public static String binToDec(String bin) {
        int dec = Integer.parseInt(bin, 2);
        return Integer.toString(dec);
    }
    
    public static String getInstructionType(String OPCODE) {
        String instructionType = "";
        switch (OPCODE) {
            case "0":
                instructionType = "RD";
                break;
            case "01":
                instructionType = "WR";
                break;
            case "02":
                instructionType = "ST";
                break;
            case "03":
                instructionType = "LW";
                break;
            case "04":
                instructionType = "MOV";
                break;
            case "05":
                instructionType = "ADD";
                break;
            case "06":
                instructionType = "SUB";
                break;
            case "07":
                instructionType = "MUL";
                break;
            case "08":
                instructionType = "DIV";
                break;
            case "09":
                instructionType = "AND";
                break;
            case "0A":
                instructionType = "OR";
                break;
            case "0B":
                instructionType = "MOVI";
                break;
            case "0C":
                instructionType = "ADDI";
                break;
            case "0D":
                instructionType = "MULI";
                break;
            case "0E":
                instructionType = "DIVI";
                break;
            case "0F":
                instructionType = "LDI";
                break;
            case "10":
                instructionType = "SLT";
                break;
            case "11":
                instructionType = "SLTI";
                break;
            case "12":
                instructionType = "HLT";
                break;
            case "13":
                instructionType = "NOP";
                break;
            case "14":
                instructionType = "JMP";
                break;
            case "15":
                instructionType = "BEQ";
                break;
            case "16":
                instructionType = "BNE";
                break;
            case "17":
                instructionType = "BEZ";
                break;
            case "18":
                instructionType = "BNZ";
                break;
            case "19":
                instructionType = "BGZ";
                break;
            case "1A":
                instructionType = "BLZ";
                break;
        }
        return instructionType;
    }
}
