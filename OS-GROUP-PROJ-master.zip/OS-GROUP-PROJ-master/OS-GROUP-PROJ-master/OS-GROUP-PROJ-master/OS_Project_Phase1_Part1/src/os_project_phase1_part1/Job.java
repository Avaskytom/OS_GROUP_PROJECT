package os_project_phase1_part1;

import java.util.ArrayList;

public class Job {
    String jobID;
    String numWordsHex;
    int priorityInt;
    ArrayList<String> instructions = new ArrayList<String>();
    ArrayList<String> dataSection = new ArrayList<String>();
    
    public Job(String jobID, String numWordsHex, String priorityStr) {
        this.jobID = jobID;
        this.numWordsHex = numWordsHex;
        this.priorityInt = Integer.parseInt(priorityStr);
    }
    
    public void addInstruction(String instruction) {
        this.instructions.add(instruction);
    }
    
    public void addDataInstruction(String dataInstruction) {
        this.dataSection.add(dataInstruction);
    }
    
    public int getPriority() {
        return this.priorityInt;
    }
}
