package os_project_phase1_part1;

import java.io.*;
import java.util.Scanner;

/*
 The loader module opens the program file. Programs are loaded into disk. Ancillary programs
 would be needed to process (strip off) the special control "cards" = which start with
 '//'. For example, the '// Job 1 17 2' control card of Job1 is processed by discarding the
 '//', noting that the '1' is the ID of the first job, noting that '17' (or 23 in decimal)
 is the number of words that constitue the instructions of Job 1, and '2' is the priority-
 number (to be used for scheduling of Job 1. All the nubmers are in hex.
 Similar logic for porcessing the data-section, following the instructions and proceded by
 '// Data ...' control cards, also applies. In the case of Job 1, for example, '// Data 14 
 C C', means Job 1's input buffer is 20 (14 in hex), its output buffer size is 12 (C in hex)
 words, and the size of its temporary buffer is 12 (C in hex) words.
 */

public class Loader {
    
    public Loader() {
        
    }
    
    public void load() {
        getJob();
    }
    
    public void getJob() {
        try {
            File f = new File("src\\os_project_phase1_part1\\ProgramFile-TextVersion.txt");
            Scanner sc = new Scanner(f);
            PCB pcb = new PCB();
            String nextLine = "";
            int temp = 1;
            
            while (sc.hasNext()) {
                nextLine = sc.nextLine();
                //pcb.extract(nextLine);
                
                if (nextLine.contains("JOB")) {
                    String jobID;
                    String numWordsHex;
                    String priorityStr;
                    int index = 0;
                    System.out.println("******** START OF JOB: " + nextLine + " ********");
                    String strippedJob = nextLine.substring(7);
                    System.out.println("strippedJob: " + strippedJob);
                    
                    while (index < strippedJob.length()) {
                        
                        jobID = getJobInfo(strippedJob, index);
                        index += jobID.length();
                        index = skipWhitespace(strippedJob, index);
                        System.out.println("jobID: " + jobID);
                        
                        numWordsHex = getJobInfo(strippedJob, index);
                        index += numWordsHex.length();
                        index = skipWhitespace(strippedJob, index);
                        System.out.println("numWordsHex: " + numWordsHex);
                        
                        priorityStr = getJobInfo(strippedJob, index);
                        index += priorityStr.length();
                        index = skipWhitespace(strippedJob, index);
                        System.out.println("priorityStr: " + priorityStr);
                        /**/
                    }
                    
                }
                if (nextLine.contains("END")) {
                    System.out.println("******** END OF JOB ********\n");
                }
            }
        } catch (FileNotFoundException ex) {
            System.out.println("error");
        }
    }
    
    public String getJobInfo(String strippedJob, int index) {
        int location = index + 1;
        while (location < strippedJob.length() && !Character.isWhitespace(strippedJob.charAt(location)))
            location++;
        return strippedJob.substring(index, location);
    }
    
    private int skipWhitespace(String line, int index) {
        int current = index;
        while (current < line.length() && Character.isWhitespace(line.charAt(current)))
            current++;
        return current;
    }
    
}
