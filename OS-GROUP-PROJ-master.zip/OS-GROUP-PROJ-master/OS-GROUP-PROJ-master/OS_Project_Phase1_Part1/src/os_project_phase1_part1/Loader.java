package os_project_phase1_part1;

import java.io.*;
import java.util.Scanner;

/*
 The loader module opens the program file. Programs are loaded into disk. Ancillary programs
 would be needed to process (strip off) the special control "cards" = which start with
 '//'. For example, the '// Job 1 17 2' control card of Job1 is processed by discarding the
 '//', noting that the '1' is the ID of the first job, noting that '17' (or 23 in decimal)
 is the number of words that constitue the instructions of Job 1, and '2' is the priority-
 number (to be used for scheduling of Job 1. All the nubmers are in hex.
 Similar logic for porcessing the data-section, following the instructions and proceded by
 '// Data ...' control cards, also applies. In the case of Job 1, for example, '// Data 14 
 C C', means Job 1's input buffer is 20 (14 in hex), its output buffer size is 12 (C in hex)
 words, and the size of its temporary buffer is 12 (C in hex) words.
 */

public class Loader {
    
    public Loader() {
        /*
        try {
            File f = new File("src\\os_project_phase1_part1\\ProgramFile-TextVersion.txt");
            Scanner sc = new Scanner(f);
            while (sc.hasNext()) {
                System.out.println(sc);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("error");
        }
        */
    }
    
    public void load() {
        
        try {
            File f = new File("src\\os_project_phase1_part1\\ProgramFile-TextVersion.txt");
            Scanner sc = new Scanner(f);
            PCB pcb = new PCB();
            String nextLine = "";
            int temp = 1;
            
            while (sc.hasNext()) {
                nextLine = sc.nextLine();
                //pcb.extract(nextLine);
                if (nextLine.length() > 2) {
                    if (nextLine.substring(0, 2).equals("//")) {
                        String strippedLine = nextLine.substring(2);
                        if (strippedLine.contains("JOB")) {
                            System.out.println("Start of Job: " + strippedLine);
                            String strippedJob = strippedLine.substring(5);
                            System.out.println(strippedJob);
                            if (!strippedLine.contains("END")) {
                                System.out.println("End of Job");
                            }
                        }
                        
                        //System.out.println(nextLine);
                    }
                }
                // System.out.println(sc.nextLine());
            }
            
            
        } catch (FileNotFoundException ex) {
            System.out.println("error");
        }
        
    }
    
}
