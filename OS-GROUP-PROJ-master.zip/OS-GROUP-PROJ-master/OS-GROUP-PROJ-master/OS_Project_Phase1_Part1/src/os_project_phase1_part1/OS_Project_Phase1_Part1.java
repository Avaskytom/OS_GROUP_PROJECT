/*
 * @authors:
 * Olivier Tran
 * Joe Eberly
 * Richard Bioh
 * Wesley Addo
 */
package os_project_phase1_part1;

public class OS_Project_Phase1_Part1 {

    public static void main(String[] args) {
        
    }
    
}
